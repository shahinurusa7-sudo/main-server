const mongoose = require('mongoose');

const statusSchema = new mongoose.Schema(
  {
    storyId: {
      type: String,
      required: true,
      unique: true,
      index: true,
    },
    userId: {
      type: String,
      required: true,
      index: true,
    },
    userName: {
      type: String,
      default: '',
    },
    userPhoto: {
      type: String,
      default: '',
    },
    content: {
      type: String,
      default: '',
      trim: true,
    },
    mediaUrl: {
      type: String,
      default: '',
    },
    mediaType: {
      type: String,
      enum: ['image', 'video', 'text'],
      default: 'image',
    },
    mediaSize: {
      width: { type: Number, default: 0 },
      height: { type: Number, default: 0 },
    },
    duration: {
      type: Number,
      default: 0, // in seconds, for videos
    },
    views: {
      type: [String], // array of user IDs who viewed
      default: [],
      index: true,
    },
    viewsCount: {
      type: Number,
      default: 0,
      index: true,
    },
    reactions: {
      type: Map,
      of: [String], // { 'heart': [userId1, userId2], 'laugh': [userId3] }
      default: {},
    },
    status: {
      type: String,
      enum: ['active', 'expired', 'deleted'],
      default: 'active',
      index: true,
    },
    createdAt: {
      type: Date,
      default: Date.now,
      index: true,
    },
    expiresAt: {
      type: Date,
      default: () => new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours
      index: true,
    },
    deletedAt: {
      type: Date,
      default: null,
    },
    allowComments: {
      type: Boolean,
      default: true,
    },
    allowDownload: {
      type: Boolean,
      default: false,
    },
    visibility: {
      type: String,
      enum: ['public', 'followers', 'private'],
      default: 'public',
    },
    linkedMatches: {
      type: [String],
      default: [], // array of match IDs to show to
    },
  },
  {
    collection: 'statuses',
    strict: false,
    timestamps: true,
  }
);

statusSchema.index({ userId: 1, status: 1 });
statusSchema.index({ expiresAt: 1, status: 1 });
statusSchema.index({ createdAt: -1 });

module.exports = mongoose.model('Status', statusSchema);
