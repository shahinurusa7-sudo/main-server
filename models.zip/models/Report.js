const mongoose = require('mongoose');

const reportSchema = new mongoose.Schema({
  reporterUid: { type: String, required: true }, // UID of user who reported
  targetUid:   { type: String, required: true }, // UID of user being reported
  reason:      { type: String, default: 'Inappropriate behavior' },
  details:     { type: String, default: '' },
  status:      { type: String, enum: ['pending', 'resolved', 'dismissed'], default: 'pending' },
  resolvedBy:  { type: String, default: null }, // Admin email
  resolvedAt:  { type: Date, default: null },
}, { timestamps: true });

module.exports = mongoose.model('Report', reportSchema);
