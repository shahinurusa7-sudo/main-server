const mongoose = require('mongoose');

/**
 * SponsorAd — Admin-uploaded sponsor advertisements.
 * These are COMPLETELY SEPARATE from Google AdMob.
 * Shown after every 4 profile scrolls in the Flutter app,
 * but ONLY when at least one active SponsorAd exists.
 */
const sponsorAdSchema = new mongoose.Schema(
  {
    // ── Identity ──────────────────────────────────────────────────
    title: {
      type: String,
      required: true,
      trim: true,
      maxlength: 80,
    },
    description: {
      type: String,
      default: '',
      trim: true,
      maxlength: 300,
    },
    brandName: {
      type: String,
      default: '',
      trim: true,
      maxlength: 60,
    },

    // ── Media ─────────────────────────────────────────────────────
    imageUrl: {
      type: String,
      required: true,     // Image is mandatory
    },
    imageFilename: {
      type: String,
      default: '',
    },

    // ── Call To Action ───────────────────────────────────────────
    ctaLabel: {
      type: String,
      default: 'Learn More',
      maxlength: 30,
    },
    ctaUrl: {
      type: String,
      default: '',
    },

    // ── Schedule ─────────────────────────────────────────────────
    startDate: {
      type: Date,
      default: null,    // null = show immediately
    },
    endDate: {
      type: Date,
      default: null,    // null = show indefinitely
    },

    // ── Priority & Display ───────────────────────────────────────
    priority: {
      type: Number,
      default: 0,
      index: true,
    },
    showAfterEvery: {
      type: Number,
      default: 4,       // show after every N profile scrolls
    },

    // ── Analytics ────────────────────────────────────────────────
    impressions: { type: Number, default: 0 },
    clicks:      { type: Number, default: 0 },

    // ── Status ───────────────────────────────────────────────────
    isActive: {
      type: Boolean,
      default: true,
      index: true,
    },

    // ── Audit ────────────────────────────────────────────────────
    uploadedBy: {
      type: String,       // admin email
      required: true,
    },
  },
  {
    collection: 'sponsor_ads',
    timestamps: true,
  }
);

sponsorAdSchema.index({ isActive: 1, priority: -1 });
sponsorAdSchema.index({ startDate: 1, endDate: 1 });

module.exports = mongoose.model('SponsorAd', sponsorAdSchema);
