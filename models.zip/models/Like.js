const mongoose = require('mongoose');

const likeSchema = new mongoose.Schema(
  {
    likeId: {
      type: String,
      required: true,
      unique: true,
      index: true,
    },
    fromUserId: {
      type: String,
      required: true,
      index: true,
    },
    toUserId: {
      type: String,
      required: true,
      index: true,
    },
    fromUserName: {
      type: String,
      default: '',
    },
    fromUserPhoto: {
      type: String,
      default: '',
    },
    isRead: {
      type: Boolean,
      default: false,
      index: true,
    },
    readAt: {
      type: Date,
      default: null,
    },
    timestamp: {
      type: Date,
      default: Date.now,
      index: true,
    },
  },
  {
    collection: 'likes',
    strict: false,
    timestamps: true,
  }
);

likeSchema.index({ toUserId: 1, timestamp: -1 });
likeSchema.index({ fromUserId: 1, toUserId: 1 }, { unique: true });

module.exports = mongoose.model('Like', likeSchema);
