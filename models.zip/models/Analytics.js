const mongoose = require('mongoose');

const analyticsSchema = new mongoose.Schema(
  {
    analyticsId: {
      type: String,
      required: true,
      unique: true,
      index: true,
    },
    adId: {
      type: String,
      required: true,
      index: true,
    },
    userId: {
      type: String,
      default: '', // user who interacted with ad, optional
      index: true,
    },
    eventType: {
      type: String,
      enum: ['impression', 'click', 'conversion', 'view_start', 'view_complete', 'engagement'],
      required: true,
      index: true,
    },
    impressions: {
      type: Number,
      default: 0,
    },
    clicks: {
      type: Number,
      default: 0,
    },
    conversions: {
      type: Number,
      default: 0,
    },
    revenue: {
      type: Number,
      default: 0,
    },
    cost: {
      type: Number,
      default: 0,
    },
    duration: {
      type: Number,
      default: 0, // in milliseconds
    },
    deviceInfo: {
      type: {
        type: String,
        enum: ['mobile', 'tablet', 'web'],
        default: 'mobile',
      },
      os: { type: String, default: '' },
      osVersion: { type: String, default: '' },
      brand: { type: String, default: '' },
      model: { type: String, default: '' },
    },
    location: {
      country: { type: String, default: '' },
      state: { type: String, default: '' },
      city: { type: String, default: '' },
    },
    userSegment: {
      ageRange: { type: String, default: '' },
      gender: { type: String, default: '' },
      interests: { type: [String], default: [] },
    },
    adFormat: {
      type: String,
      enum: ['banner', 'interstitial', 'rewarded', 'native'],
      default: 'banner',
    },
    placement: {
      type: String,
      enum: ['discovery_feed', 'profile_view', 'match_screen', 'chat_screen', 'between_matches'],
      default: 'discovery_feed',
    },
    conversionValue: {
      type: Number,
      default: 0,
    },
    conversionType: {
      type: String,
      default: 'click',
    },
    timestamp: {
      type: Date,
      default: Date.now,
      index: true,
    },
    date: {
      type: Date,
      default: () => {
        const now = new Date();
        return new Date(now.getFullYear(), now.getMonth(), now.getDate());
      },
      index: true,
    },
    hour: {
      type: Number,
      default: () => new Date().getHours(),
    },
    dayOfWeek: {
      type: Number,
      default: () => new Date().getDay(),
    },
  },
  {
    collection: 'analytics',
    strict: false,
    timestamps: false,
  }
);

analyticsSchema.index({ adId: 1, eventType: 1 });
analyticsSchema.index({ date: 1, adId: 1 });
analyticsSchema.index({ userId: 1, timestamp: 1 });
analyticsSchema.index({ timestamp: -1 });

module.exports = mongoose.model('Analytics', analyticsSchema);
