const mongoose = require('mongoose');

const locationSchema = new mongoose.Schema(
  {
    country: { type: String, default: '' },
    state: { type: String, default: '' },
    city: { type: String, default: '' },
    coordinates: { type: mongoose.Schema.Types.Mixed, default: null },
  },
  { _id: false, strict: false }
);

const userSchema = new mongoose.Schema(
  {
    uid: {
      type: String,
      required: true,
      unique: true,
      index: true,
      trim: true,
    },
    email: { type: String, default: null, trim: true, lowercase: true, sparse: true, unique: true },
    displayName: { type: String, default: '', trim: true },
    photoURL: { type: String, default: '' },
    photos: { type: [String], default: [] },
    gender: {
      type: String,
      enum: { values: ['male', 'female', 'other', ''], message: 'Gender must be "male", "female", "other", or empty' },
      lowercase: true,
      trim: true,
      default: '',
      validate: {
        validator: function(v) {
          // Allow empty string, 'male', 'female', 'other'
          return !v || ['male', 'female', 'other'].includes(v.toLowerCase());
        },
        message: 'Invalid gender value. Expected "male", "female", or "other"'
      }
    },
    age: { type: Number, default: 18 },
    bio: { type: String, default: '' },
    location: { type: locationSchema, default: () => ({}) },
    interests: { type: [String], default: [] },
    languages: { type: [String], default: [] },
    likedUsers: { type: [String], default: [] },
    likedBy: { type: [String], default: [] },
    matches: { type: [String], default: [] },
    blockedUsers: { type: [String], default: [] },
    blockedBy: { type: [String], default: [] },
    verified: { type: Boolean, default: false },
    isProfileComplete: { type: Boolean, default: false },
    online: { type: Boolean, default: false, index: true },
    lastSeen: { type: Date, default: null },
    profileViews: { type: Number, default: 0 },
    lastViewedAt: { type: Date, default: null },
    fcmToken: { type: String, default: '', trim: true },
    welcomeEmailSentAt: { type: Date, default: null },
    welcomeEmailLockAt: { type: Date, default: null },
    welcomeEmailRecipient: { type: String, default: '' },
    welcomeEmailError: { type: String, default: '' },
    isBanned: { type: Boolean, default: false },
    isActive: { type: Boolean, default: true },
  },
  {
    collection: 'users',
    strict: false,
    timestamps: true,
  }
);

userSchema.index({ updatedAt: -1 });
userSchema.index({ gender: 1 }); // Index for gender-based queries (video matching)
userSchema.index({ verified: 1, isProfileComplete: 1 }); // Index for profile completeness checks

// Middleware to normalize gender before saving
userSchema.pre('save', function(next) {
  if (this.gender) {
    this.gender = this.gender.toLowerCase().trim();
    if (!['male', 'female', 'other'].includes(this.gender)) {
      this.gender = '';
    }
  }
  next();
});

// Static method to normalize gender value
userSchema.statics.normalizeGender = function(gender) {
  if (!gender) return '';
  const normalized = gender.toLowerCase().trim();
  if (normalized.startsWith('m')) return 'male';
  if (normalized.startsWith('f')) return 'female';
  if (normalized === 'other') return 'other';
  return '';
};

// Static method to get opposite gender
userSchema.statics.getOppositeGender = function(gender) {
  const normalized = this.normalizeGender(gender);
  if (normalized === 'male') return 'female';
  if (normalized === 'female') return 'male';
  return null; // 'other' doesn't have an opposite
};

// Instance method: is gender valid for video matching?
userSchema.methods.isValidForVideoMatching = function() {
  return this.isProfileComplete && this.verified && 
         ['male', 'female'].includes(this.gender);
};

module.exports = mongoose.model('User', userSchema);
