const mongoose = require('mongoose');

const adSchema = new mongoose.Schema(
  {
    adId: {
      type: String,
      required: true,
      unique: true,
      index: true,
    },
    advertiserId: {
      type: String,
      required: true,
      index: true,
    },
    advertiserName: {
      type: String,
      default: '',
    },
    title: {
      type: String,
      required: true,
      trim: true,
    },
    description: {
      type: String,
      default: '',
      trim: true,
    },
    content: {
      type: String,
      default: '',
    },
    imageUrl: {
      type: String,
      default: '',
    },
    videoUrl: {
      type: String,
      default: '',
    },
    adType: {
      type: String,
      enum: ['banner', 'interstitial', 'rewarded', 'native'],
      default: 'banner',
      index: true,
    },
    callToAction: {
      text: { type: String, default: 'Learn More' },
      url: { type: String, default: '' },
      deepLink: { type: String, default: '' },
    },
    targetAudience: {
      ageMin: { type: Number, default: 18 },
      ageMax: { type: Number, default: 65 },
      genders: { type: [String], default: ['male', 'female'] },
      interests: { type: [String], default: [] },
      locations: { type: [String], default: [] },
      languages: { type: [String], default: [] },
    },
    budget: {
      totalBudget: { type: Number, default: 0 },
      dailyBudget: { type: Number, default: 0 },
      currencyCode: { type: String, default: 'USD' },
      spent: { type: Number, default: 0 },
    },
    schedule: {
      startDate: { type: Date, required: true },
      endDate: { type: Date, required: true },
      timezone: { type: String, default: 'UTC' },
    },
    status: {
      type: String,
      enum: ['draft', 'pending_review', 'approved', 'active', 'paused', 'ended', 'rejected'],
      default: 'draft',
      index: true,
    },
    priority: {
      type: Number,
      default: 0,
      index: true,
    },
    frequency: {
      maxImpressions: { type: Number, default: -1 }, // -1 = unlimited
      maxClick: { type: Number, default: -1 },
      impressionPerUser: { type: Number, default: 3 },
    },
    analytics: {
      impressions: { type: Number, default: 0 },
      clicks: { type: Number, default: 0 },
      conversions: { type: Number, default: 0 },
      ctr: { type: Number, default: 0 }, // click-through rate
      cpc: { type: Number, default: 0 }, // cost per click
      cpm: { type: Number, default: 0 }, // cost per thousand impressions
    },
    metrics: {
      viewedByUsers: { type: [String], default: [] },
      clickedByUsers: { type: [String], default: [] },
      convertedByUsers: { type: [String], default: [] },
    },
    createdAt: {
      type: Date,
      default: Date.now,
      index: true,
    },
    updatedAt: {
      type: Date,
      default: Date.now,
    },
    reviewedAt: {
      type: Date,
      default: null,
    },
    reviewedBy: {
      type: String,
      default: '',
    },
    rejectionReason: {
      type: String,
      default: '',
    },
    isActive: {
      type: Boolean,
      default: false,
      index: true,
    },
  },
  {
    collection: 'ads',
    strict: false,
    timestamps: false,
  }
);

adSchema.index({ advertiserId: 1, status: 1 });
adSchema.index({ adType: 1, priority: -1 });
adSchema.index({ 'schedule.startDate': 1, 'schedule.endDate': 1 });

module.exports = mongoose.model('Ad', adSchema);
