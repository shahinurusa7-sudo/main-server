const mongoose = require('mongoose');

/**
 * Admin roles and their permissions.
 *
 * super_admin   — owner, full access
 * moderator     — photos, reports, temp bans
 * support       — tickets, account restore
 * marketing     — notifications, campaigns
 * finance       — revenue, refunds (read-only)
 */
const ROLES = ['super_admin', 'moderator', 'support', 'marketing', 'finance'];

const PERMISSIONS = {
  super_admin: ['*'],  // wildcard = everything
  moderator: ['view_users', 'ban_user', 'delete_photo', 'view_reports', 'resolve_report'],
  support: ['view_users', 'restore_account', 'view_reports'],
  marketing: ['send_notification', 'view_analytics', 'manage_sponsor_ads'],
  finance: ['view_revenue', 'view_analytics'],
};

const adminSchema = new mongoose.Schema(
  {
    email: {
      type: String, required: true, unique: true, trim: true, lowercase: true,
    },
    role: {
      type: String, enum: ROLES, default: 'moderator',
    },
    displayName: { type: String, default: '' },

    // OTP (passwordless auth)
    otp: { type: String, default: null },
    otpExpires: { type: Date, default: null },
    otpAttempts: { type: Number, default: 0 }, // failed attempt counter
    otpSentAt: { type: Date, default: null }, // rate-limit reference

    // Session
    lastLogin: { type: Date, default: null },
    lastIp: { type: String, default: '' },
    lastDevice: { type: String, default: '' },

    isActive: { type: Boolean, default: true },
    createdBy: { type: String, default: 'system' }, // email of super_admin who created
  },
  { timestamps: true, collection: 'admins' }
);

// Instance helper: check a single permission
adminSchema.methods.can = function (permission) {
  const perms = PERMISSIONS[this.role] || [];
  return perms.includes('*') || perms.includes(permission);
};

// Expose constants so backend middleware can import them
adminSchema.statics.ROLES = ROLES;
adminSchema.statics.PERMISSIONS = PERMISSIONS;

module.exports = mongoose.model('Admin', adminSchema);
