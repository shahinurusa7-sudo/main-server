const mongoose = require('mongoose');
const crypto = require('crypto');

/**
 * Admin roles and their permissions.
 */
const ROLES = ['super_admin', 'moderator', 'support', 'marketing', 'finance'];

const PERMISSIONS = {
  super_admin: ['*'],  // wildcard = everything
  moderator: ['view_users', 'ban_user', 'delete_photo', 'view_reports', 'resolve_report'],
  support: ['view_users', 'restore_account', 'view_reports'],
  marketing: ['send_notification', 'view_analytics', 'manage_sponsor_ads'],
  finance: ['view_revenue', 'view_analytics'],
};

const adminSchema = new mongoose.Schema(
  {
    email: {
      type: String, required: true, unique: true, trim: true, lowercase: true,
    },
    password: { 
      type: String, 
      default: null,
      select: true // Ensure it's available for auth
    },
    role: {
      type: String, enum: ROLES, default: 'moderator',
    },
    displayName: { type: String, default: '' },

    // OTP (legacy/fallback)
    otp: { type: String, default: null },
    otpExpires: { type: Date, default: null },
    
    // Session
    lastLogin: { type: Date, default: null },
    lastIp: { type: String, default: '' },
    lastDevice: { type: String, default: '' },

    isActive: { type: Boolean, default: true },
    createdBy: { type: String, default: 'system' },
  },
  { timestamps: true, collection: 'admins' }
);

// ─── Password Hashing ────────────────────────────────────────────────────────
adminSchema.pre('save', function (next) {
  if (!this.isModified('password') || !this.password) return next();
  
  try {
    const salt = crypto.randomBytes(16).toString('hex');
    const hash = crypto.pbkdf2Sync(this.password, salt, 1000, 64, 'sha512').toString('hex');
    this.password = `${salt}:${hash}`;
    next();
  } catch (err) {
    next(err);
  }
});

// Instance helper: verify password
adminSchema.methods.verifyPassword = function (candidate) {
  if (!this.password || !this.password.includes(':')) return false;
  const [salt, hash] = this.password.split(':');
  const candidateHash = crypto.pbkdf2Sync(candidate, salt, 1000, 64, 'sha512').toString('hex');
  return hash === candidateHash;
};

// Instance helper: check a single permission
adminSchema.methods.can = function (permission) {
  const perms = PERMISSIONS[this.role] || [];
  return perms.includes('*') || perms.includes(permission);
};

// Expose constants
adminSchema.statics.ROLES = ROLES;
adminSchema.statics.PERMISSIONS = PERMISSIONS;

module.exports = mongoose.model('Admin', adminSchema);
