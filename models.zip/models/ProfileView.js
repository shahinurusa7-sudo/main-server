const mongoose = require('mongoose');

const profileViewSchema = new mongoose.Schema(
  {
    ownerUserId: {
      type: String,
      required: true,
      index: true,
    },
    viewerId: {
      type: String,
      required: true,
      index: true,
    },
    viewedAt: {
      type: Date,
      default: Date.now,
      index: true,
    },
  },
  {
    collection: 'profile_views',
    strict: false,
    timestamps: true,
  }
);

profileViewSchema.index({ ownerUserId: 1, viewerId: 1 }, { unique: true });
profileViewSchema.index({ ownerUserId: 1, viewedAt: -1 });

module.exports = mongoose.model('ProfileView', profileViewSchema);
