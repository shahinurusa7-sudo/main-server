const mongoose = require('mongoose');

const matchSchema = new mongoose.Schema(
  {
    matchId: {
      type: String,
      required: true,
      unique: true,
      index: true,
    },
    user1Id: {
      type: String,
      required: true,
      index: true,
    },
    user2Id: {
      type: String,
      required: true,
      index: true,
    },
    participants: {
      type: [String],
      required: true,
      default: [],
    },
    status: {
      type: String,
      enum: ['active', 'deleted'],
      default: 'active',
      index: true,
    },
    timestamp: {
      type: Date,
      default: Date.now,
      index: true,
    },
    deletedAt: {
      type: Date,
      default: null,
    },
  },
  {
    collection: 'matches',
    strict: false,
    timestamps: true,
  }
);

matchSchema.index({ participants: 1, status: 1 });

module.exports = mongoose.model('Match', matchSchema);
